package Logica;

public class Cajero {

}
