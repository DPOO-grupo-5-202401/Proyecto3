package Logica;

public class Autor {

}
